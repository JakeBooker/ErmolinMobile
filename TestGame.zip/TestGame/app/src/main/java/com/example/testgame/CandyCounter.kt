package com.example.testgame

import android.os.Handler
import android.content.Context
import android.content.SharedPreferences
import java.util.*
import android.app.Application


class CandyCounter(context: Context)  {

    private val sharedPreferences: SharedPreferences =
        context.getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)
    private var candyCount: Int = 0


    private val timer = Timer()

    init {
        loadCandyCount()

        // Запускаем таймер для увеличения количества конфет каждую секунду
        timer.scheduleAtFixedRate(object : TimerTask() {
            override fun run() {
                incrementCandyCount()
            }
        }, 1000, 1000) // Первый запуск через 1 секунду, затем каждую секунду
    }


    fun getCandyCount(): Int {
        return candyCount

    }

    fun incrementCandyCountFromBattle(amount: Int) {
        candyCount += amount
        saveCandyCount()
    }

    fun incrementCandyCount() {
        candyCount++
        saveCandyCount()
    }

    fun decrementCandyCount() {
        candyCount = 0
        saveCandyCount()
    }

    fun buysinshop(amount: Int){
        candyCount -= amount
        saveCandyCount()
    }

    fun saveCandyCount() {
        sharedPreferences.edit().putInt("candyCount", candyCount).apply()
    }

    fun loadCandyCount() {
        candyCount = sharedPreferences.getInt("candyCount", 0)
    }



}

